import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_application_3/Praktek/HistoryScreen.dart';
import 'package:flutter_application_3/Praktek/ItemsScreen.dart';
import 'package:flutter_application_3/Praktek/ListDialog.dart';
import 'package:flutter_application_3/Praktek/Provider/MyProvider.dart';
import 'package:flutter_application_3/Praktek/Model/ShoppingList.dart';
import 'package:flutter_application_3/Praktek/DB/dbhelper.dart';
import 'package:flutter_application_3/Praktek/HistoryProvider.dart';
//import 'package:flutter_application_3/Praktek/ui/shopping_list_dialog.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Screen extends StatefulWidget {
  const Screen({Key? key}) : super(key: key);

  @override
  State<Screen> createState() => _ScreenState();
}

class _ScreenState extends State<Screen> {
  int id = 0;
  DBHelper _dbHelper = DBHelper();

  @override
  void initState() {
    super.initState();
    _loadLastId();
  }

  Future<void> _loadLastId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      id = prefs.getInt('lastId') ?? 0;
    });
  }

  Future<void> _saveLastId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('lastId', id);
  }

  Future<void> _deleteAllShoppingList() async {
    await _dbHelper.deleteAllShoppingList();
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Shopping list deleted')));
    List<ShoppingList> shoppingList =
        Provider.of<ListProductProvider>(context, listen: false)
            .getShoppingList;
    for (var item in shoppingList) {
      await HistoryProvider.addDeletionToHistory(item.toMap());
    }
  }

  @override
  Widget build(BuildContext context) {
    var tmp = Provider.of<ListProductProvider>(context, listen: true);
    _dbHelper.getmyShoppingList().then((value) => tmp.setShoppingList = value);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping List'),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.delete),
            tooltip: 'Delete All',
            onPressed: () {
              _deleteAllShoppingList();
            },
          ),
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: ((context) => HistoryScreen()),
                  ));
            },
          ),
        ],
      ),
      body: ListView.builder(
          itemCount:
              tmp.getShoppingList != null ? tmp.getShoppingList.length : 0,
          itemBuilder: (BuildContext context, int index) {
            return Dismissible(
                key: Key(tmp.getShoppingList[index].id.toString()),
                onDismissed: (direction) {
                  String tmpName = tmp.getShoppingList[index].name;
                  int tmpId = tmp.getShoppingList[index].id;
                  setState(() {
                    tmp.deleteById(tmp.getShoppingList[index]);
                  });
                  _dbHelper.deleteShoppingList(tmpId);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('$tmpName delete'),
                  ));
                },
                child: ListTile(
                  title: Text(tmp.getShoppingList[index].name),
                  leading: CircleAvatar(
                    child: Text('${tmp.getShoppingList[index].sum}'),
                  ),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return ItemScreen(tmp.getShoppingList[index]);
                    }));
                  },
                  trailing: IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () {
                        showDialog(
                            context: context,
                            builder: (context) {
                              return ShoppingListDialog(_dbHelper).buildDialog(
                                  context, tmp.getShoppingList[index], false);
                            });
                        _dbHelper
                            .getmyShoppingList()
                            .then((value) => tmp.setShoppingList = value);
                      }),
                ));
          }),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await showDialog(
              context: context,
              builder: (context) {
                return ShoppingListDialog(_dbHelper)
                    .buildDialog(context, ShoppingList(++id, '', 0), true);
              });
          _dbHelper
              .getmyShoppingList()
              .then((value) => tmp.setShoppingList = value);
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  @override
  void dispose() {
    _dbHelper.closeDB();
    super.dispose();
  }
}
