import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_application_5/detailscreen.dart';
import 'package:flutter_application_5/helper.dart';
import 'package:flutter_application_5/search.dart';

enum MovieCategory { latest, nowPlaying, popular, topRated, upcoming }

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  MovieCategory _selectedCategory = MovieCategory.nowPlaying;
  StreamController<List?> streamController = StreamController<List?>();
  
  TextEditingController search = TextEditingController();
  String cari = '';

  HttpHelper? helper;
  List? movies;
  final String iconBase = 'https://image.tmdb.org/t/p/w92/';
  final String defaultImage =
      'https://images.freeimages.com/images/large-previews/5eb/movie-clapboard-1184339.jpg';

  void initialize() {
    helper?.getMovies(_selectedCategory).listen((movies) {
      streamController.add(movies);
    });
  }

  @override
  void initState() {
    helper = HttpHelper();
    Timer.periodic(const Duration(seconds: 5), (Timer t) => initialize());
    super.initState();
  }

  @override
  void dispose() {
    streamController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    NetworkImage image;
    String getAppBarTitle(MovieCategory category) {
      switch (category) {
        case MovieCategory.latest:
          return 'Latest';
        case MovieCategory.nowPlaying:
          return 'Now Playing';
        case MovieCategory.popular:
          return 'Popular';
        case MovieCategory.topRated:
          return 'Top Rated';
        case MovieCategory.upcoming:
          return 'Up Coming';
        default:
          return '';
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(getAppBarTitle(_selectedCategory)),
        actions: <Widget>[
          // IconButton(
          //   onPressed: () {
          //     MaterialPageRoute route =
          //         MaterialPageRoute(builder: (_) => const SearchMovie());
          //     Navigator.push(context, route);
          //   },
          //   icon: Icon(Icons.search),
          // ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.white,
              ),
              margin: const EdgeInsets.all(10),
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
              child: TextFormField(
                controller: search,
                decoration: const InputDecoration(
                  suffixIcon: Icon(Icons.search),
                  hintText: "Search The Movie",
                  // border: OutlineInputBorder(
                  //   borderSide: BorderSide(
                  //     color: Colors.white,
                  //   )
                  // )
                ),
                onChanged: (value) {
                  setState(() {
                    cari = value;
                  });
                },
              ),
            ),
          ),
          PopupMenuButton<MovieCategory>(
              onSelected: (MovieCategory result) {
                setState(() {
                  _selectedCategory = result;
                  initialize();
                });
              },
              itemBuilder: (BuildContext context) =>
                  <PopupMenuEntry<MovieCategory>>[
                    const PopupMenuItem(
                      value: MovieCategory.latest,
                      child: Text('Latest'),
                    ),
                    const PopupMenuItem(
                      value: MovieCategory.nowPlaying,
                      child: Text('Now Playing'),
                    ),
                    const PopupMenuItem(
                      value: MovieCategory.popular,
                      child: Text('Popular'),
                    ),
                    const PopupMenuItem(
                      value: MovieCategory.topRated,
                      child: Text('Top Rated'),
                    ),
                    const PopupMenuItem(
                      value: MovieCategory.upcoming,
                      child: Text('Up Coming'),
                    ),
                  ]),
        ],
      ),
      body: StreamBuilder<List?>(
        stream: streamController.stream,
        builder: (BuildContext context, AsyncSnapshot<List?> snapshot) {
          if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return const Center(child: CircularProgressIndicator());
            default:
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data?.length ?? 0,
                  itemBuilder: (BuildContext context, int position) {
                    ImageProvider image;
                    if (snapshot.data![position].posterPath != null) {
                      image = NetworkImage(
                          iconBase + snapshot.data![position].posterPath);
                    } else {
                      image = NetworkImage(defaultImage);
                    }
                    return Visibility(
                      visible: snapshot.data![position].title.toString().toLowerCase().contains(cari.toLowerCase()),
                      child: Card(
                        color: Colors.white,
                        elevation: 2.0,
                        child: ListTile(
                          onTap: () {
                            MaterialPageRoute route = MaterialPageRoute(
                                builder: (_) =>
                                    DetailScreen(snapshot.data![position]));
                            Navigator.push(context, route);
                          },
                          leading: CircleAvatar(
                            backgroundImage: image,
                          ),
                          title: Text(snapshot.data![position].title),
                          subtitle: Text('Released: ' +
                              snapshot.data![position].releaseDate +
                              ' - Vote: ' +
                              snapshot.data![position].voteAverage.toString()),
                        ),
                      ),
                    );
                  },
                );
              } else {
                return const Text('No data');
              }
          }
        },
      ),
    );
  }
}
