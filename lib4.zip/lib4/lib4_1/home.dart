import 'package:flutter/material.dart';
import 'package:flutter_application_4_1/HttpHelper.dart';

class MyHome extends StatefulWidget {
  const MyHome({Key? key}) : super(key: key);

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  late List result;
  late Httphelper helper;

  @override
  void initState() {
    super.initState();
    helper = Httphelper();
    result = [
      {'setup': '', 'punchline': ''}
    ];

    helper.getMovie().then((value) {
      setState(() {
        result = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bercandyaa')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Text('Joker: ${result[0]['setup']}'),
            Text('Punched: ${result[0]['punchline']}'),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
              onPressed:() {
                helper.getMovie().then((value) {
                  setState(() {
                    result = value;
                  });
                });
              },
              child: Text('Random'))
          ],
        ),
      ),
    );
  }
}