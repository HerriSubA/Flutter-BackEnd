import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

class Httphelper {
  final String _urlBase = 'https://official-joke-api.appspot.com/jokes/programming/random';

  Future<List> getMovie() async {
    var url = Uri.parse(_urlBase);
    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      List responseBody = json.decode(result.body);
      return responseBody;
    }
    return [];
  }
}