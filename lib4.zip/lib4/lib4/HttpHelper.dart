import 'dart:io';
import 'package:http/http.dart' as http;

class HttpHelper {
  final String _urlKey = '?api_key=1bc114ad3461e6bf174eaf26fcd370e1';
  final String _urlBase = 'https://api.themoviedb.org/';
  String _urlKategori = 'now_playing';

  Future<String> getMovie() async {
    var url = Uri.parse(_urlBase + '/3/movie/' + urlKategori + _urlKey);
    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      String responseBody = result.body;
      return responseBody;
    }
    return result.statusCode.toString();
  }

  String get urlKategori => _urlKategori;
  set urlKategori(value) {
    _urlKategori = value;
  }
}