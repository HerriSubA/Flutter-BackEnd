import 'package:flutter/material.dart';
import 'package:flutter_application_4/HttpHelper.dart';

class MyHome extends StatefulWidget {
  const MyHome({Key? key}) : super(key: key);

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  Map kategori = {
    'now_playing': 'Now Playing',
    'popular': 'Popular',
    'latest': 'Latest',
    'top_rated': 'Top Rated',
    'upcoming': 'Upcoming',
  };
  late String result;
  late HttpHelper helper;

  @override
  void initState() {
    super.initState();
    helper = HttpHelper();
    result = '';

    helper.getMovie().then((value) {
      setState(() {
        result = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My Movie'),),
      body: SingleChildScrollView(
        child: Column(
          children: [
            DropdownButton(
              value: helper.urlKategori,
               onChanged:(value) {
                 setState(() {
                   helper.urlKategori = value;
                 });
                 helper.getMovie().then((value) {
                  setState(() {
                    result = value;
                  });
                 });
               },
              items: kategori.entries.map((value) {
                return DropdownMenuItem(
                  value: value.key,
                  child: Text(value.value),
                );
              }).toList(),
            ),
            Text('$result'),
          ],
        ),
      ),
    );
  }
}
