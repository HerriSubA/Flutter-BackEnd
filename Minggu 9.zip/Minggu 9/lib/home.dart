import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_9/Praktek/EventModel.dart';

class MyHome extends StatefulWidget {
  const MyHome({Key? key}) : super(key: key);

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  @override
  void initState() {
    readData();
    super.initState();
  }
  
  Future testData() async {
    await Firebase.initializeApp();
    print('init Done');
    FirebaseFirestore db = await FirebaseFirestore.instance;
    print('init Firestore Done');

    var data = await db.collection('event_detail').get().then((event) {
    for(var doc in event.docs) {
      print('${doc.id} => ${doc.data()}');
    }
  });
  }

  Future readData() async {
    await Firebase.initializeApp();
    FirebaseFirestore db = await FirebaseFirestore.instance;
    var data = await db.collection('event_detail').get();
    setState(() {
      details = data.docs.map((doc) => EventModel.fromDocSnapshot(doc)).toList();
    });
  }

  addRand() async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    EventModel InsertData = EventModel(
      judul: getRandString(5),
      keterangan: getRandString(30),
      tanggal: getRandString(10),
      is_like: Random().nextBool(),
      pembicara: getRandString(20)
    );
    await db.collection('event_detail').add(InsertData.toMap());
    setState(() {
      details.add(InsertData);
    });
  }

  String getRandString(int len) {
    var random = Random.secure();
    var values = List<int>.generate(len, (i) => random.nextInt(255));
    return base64UrlEncode(values);
  }

  deleteLast(String documentId) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    await db.collection('event_detail').doc(documentId).delete();
    setState(() {
      details.removeLast();
    });
  }

  updateEvent(int pos) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    await db
      .collection('event_detail')
      .doc(details[pos].id)
      .update({'is_like': !details[pos].is_like});
    setState(() {
      details[pos].is_like = !details[pos].is_like;
    });
  }

  List<EventModel> details = [];
  @override
  Widget build(BuildContext context) {
    testData();
    return Scaffold(
      appBar: AppBar(title: Text('Cloud Firestore'),),
      body: ListView.builder(
        itemCount: (details != null) ? details.length : 0 ,
        itemBuilder: (context, position) {
          return CheckboxListTile(
            value: details[position].is_like,
            title: Text(details[position].judul),
            subtitle: Text(
              '${details[position].keterangan}' + 
              '\nHari : ${details[position].tanggal}' + 
              '\nPembicara: ${details[position].pembicara}'
            ),
            isThreeLine: false,
            onChanged: (bool? value) {
              updateEvent(position);
            }
          );
        }),
      floatingActionButton: FabCircularMenu(
        children: <Widget>[
          IconButton(
            onPressed: () async {
              addRand();
            },
            icon: Icon(Icons.add)
          ),
          IconButton(
            onPressed: () async {
              if(details.last.id != null) {
                deleteLast(details.last.id!);
              }
            },
            icon: Icon(Icons.minimize)
          ),
        ]
      ),
    );
  }
}